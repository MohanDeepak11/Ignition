SELECT column_a, column_b
FROM my_table
WHERE column_x = :myValueX
    AND column_y = :myValueY